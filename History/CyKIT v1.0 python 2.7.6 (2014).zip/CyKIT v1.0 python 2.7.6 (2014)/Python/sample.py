# -*- encoding: utf-8 -*-
from CyKit.emotiv import Emotiv

import unittest

class TestEmotiv(unittest.TestCase):
    def test_emotiv(self):
        emotiv = Emotiv()

